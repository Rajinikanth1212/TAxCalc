package com.txcalculator;

import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaxCalculatorTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testCalculatTaxForNoData() {
		final TaxDetails result = new TaxCalculator().calculateTax("");
		assertEquals(result.getFederalTax(), new TaxDetails(0, 0, 0).getFederalTax());
		assertEquals(result.getProvincialTax(), new TaxDetails(0, 0, 0).getProvincialTax());
		assertEquals(result.getTotalTax(), new TaxDetails(0, 0, 0).getTotalTax());
	}
	
	@Test
	void testCalculatTaxForZero() {
		final TaxDetails result = new TaxCalculator().calculateTax("0");
		assertEquals(result.getFederalTax(), new TaxDetails(0, 0, 0).getFederalTax());
		assertEquals(result.getProvincialTax(), new TaxDetails(0, 0, 0).getProvincialTax());
		assertEquals(result.getTotalTax(), new TaxDetails(0, 0, 0).getTotalTax());
	}
	
	@Test
	void testCalculatTaxForIncome() {
		final TaxDetails result = new TaxCalculator().calculateTax("100000");
		assertEquals(result.getFederalTax(), new TaxDetails(13300.949999999999, 0, 0).getFederalTax());
		assertEquals(result.getProvincialTax(), new TaxDetails(0, 4551.918500000001, 0).getProvincialTax());
		assertEquals(result.getTotalTax(), new TaxDetails(0, 0, 17852.8685).getTotalTax());
	}
	
	@Test
	void testCalculatTaxForNegetiveIncome() {
		final TaxDetails result = new TaxCalculator().calculateTax("-3000");
		assertEquals(result.getFederalTax(), new TaxDetails(0, 0, 0).getFederalTax());
		assertEquals(result.getProvincialTax(), new TaxDetails(0, 0, 0).getProvincialTax());
		assertEquals(result.getTotalTax(), new TaxDetails(0, 0, 0).getTotalTax());
	}

}
