package com.txcalculator;

public class TaxDetails {

	private  double federalTax;
	private double provincialTax;
	private double totalTax;
	
	
	public TaxDetails(double federalTax, double provincialTax, double totalTax) {
		super();
		this.federalTax = federalTax;
		this.provincialTax = provincialTax;
		this.totalTax = totalTax;
	}
	public double getFederalTax() {
		return federalTax;
	}
	public void setFederalTax(double federalTax) {
		this.federalTax = federalTax;
	}
	public double getProvincialTax() {
		return provincialTax;
	}
	public void setProvincialTax(double provincialTax) {
		this.provincialTax = provincialTax;
	}
	public double getTotalTax() {
		return totalTax;
	}
	public void setTotalTax(double totalTax) {
		this.totalTax = totalTax;
	}
	@Override
	public String toString() {
		return "TaxDetails [federalTax=" + federalTax + ", provincialTax=" + provincialTax + ", totalTax=" + totalTax
				+ "]";
	}
	
	
}
