package com.txcalculator;

public class TaxCalculator {
	public static void main(String[] args) {     

		TaxDetails details =  new TaxCalculator().calculateTax("100000");
		System.out.println(details.toString());
	}
	

	public TaxDetails calculateTax(String userIncome)
	{

		if("".equals(userIncome))
			return new TaxDetails(0, 0, 0);
		
	    double uIncome= Double.parseDouble(userIncome);
	    
	    if(uIncome <= 0) {
	    	return new TaxDetails(0, 0, 0);
	    }
	    
	    double federalExemption= 11327.0;
	    double provincialExemption = 9863.0;
	    double federalTax =  (uIncome - federalExemption) * 0.15;
	    double provincialTax = (uIncome - provincialExemption) * 0.0505;
	    double totalTax = federalTax + provincialTax;
	    
	    return new TaxDetails(federalTax, provincialTax, totalTax);
	}

}
